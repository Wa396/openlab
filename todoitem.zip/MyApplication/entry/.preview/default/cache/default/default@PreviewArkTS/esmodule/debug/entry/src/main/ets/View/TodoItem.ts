if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Index_Params {
    todoList?: TodoItem[];
    newTodoTitle?: string;
}
export class TodoItem {
    id: number;
    title: string;
    completed: boolean;
    createTime: string;
    constructor(title: string) {
        this.id = new Date().getTime();
        this.title = title;
        this.completed = false;
        this.createTime = new Date().toLocaleString();
    }
}
class Index extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__todoList = new ObservedPropertyObjectPU([
            new TodoItem('学习 ArkUI 框架'),
            new TodoItem('完成 OpenLab 考核'),
            new TodoItem('部署个人网站')
        ], this, "todoList");
        this.__newTodoTitle = new ObservedPropertySimplePU('', this, "newTodoTitle");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Index_Params) {
        if (params.todoList !== undefined) {
            this.todoList = params.todoList;
        }
        if (params.newTodoTitle !== undefined) {
            this.newTodoTitle = params.newTodoTitle;
        }
    }
    updateStateVars(params: Index_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__todoList.purgeDependencyOnElmtId(rmElmtId);
        this.__newTodoTitle.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__todoList.aboutToBeDeleted();
        this.__newTodoTitle.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __todoList: ObservedPropertyObjectPU<TodoItem[]>;
    get todoList() {
        return this.__todoList.get();
    }
    set todoList(newValue: TodoItem[]) {
        this.__todoList.set(newValue);
    }
    private __newTodoTitle: ObservedPropertySimplePU<string>;
    get newTodoTitle() {
        return this.__newTodoTitle.get();
    }
    set newTodoTitle(newValue: string) {
        this.__newTodoTitle.set(newValue);
    }
    addTodo() {
        if (this.newTodoTitle.trim().length > 0) {
            const newTodo = new TodoItem(this.newTodoTitle.trim());
            this.todoList.push(newTodo);
            this.newTodoTitle = '';
        }
    }
    toggleTodo(index: number) {
        this.todoList[index].completed = !this.todoList[index].completed;
    }
    deleteTodo(index: number) {
        this.todoList.splice(index, 1);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: 20 });
            Column.debugLine("entry/src/main/ets/View/TodoItem.ets(44:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.padding(20);
            Column.backgroundColor('#F5F5F5');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('待办');
            Text.debugLine("entry/src/main/ets/View/TodoItem.ets(45:7)", "entry");
            Text.fontSize(30);
            Text.fontWeight(FontWeight.Bold);
            Text.fontColor(Color.Black);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 10 });
            Row.debugLine("entry/src/main/ets/View/TodoItem.ets(50:7)", "entry");
            Row.width('100%');
            Row.padding(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({
                placeholder: '输入新的待办事项...',
                text: this.newTodoTitle
            });
            TextInput.debugLine("entry/src/main/ets/View/TodoItem.ets(51:9)", "entry");
            TextInput.layoutWeight(1);
            TextInput.onChange((value: string) => {
                this.newTodoTitle = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('添加');
            Button.debugLine("entry/src/main/ets/View/TodoItem.ets(60:9)", "entry");
            Button.backgroundColor('#007DFF');
            Button.fontColor(Color.White);
            Button.onClick(() => {
                this.addTodo();
            });
        }, Button);
        Button.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create({ space: 10 });
            List.debugLine("entry/src/main/ets/View/TodoItem.ets(70:7)", "entry");
            List.layoutWeight(1);
            List.width('100%');
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.debugLine("entry/src/main/ets/View/TodoItem.ets(72:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create({ space: 15 });
                            Row.debugLine("entry/src/main/ets/View/TodoItem.ets(73:13)", "entry");
                            Row.width('100%');
                            Row.padding(15);
                            Row.backgroundColor(Color.White);
                            Row.borderRadius(8);
                            Row.shadow({ radius: 2, color: '#00000016', offsetX: 0, offsetY: 1 });
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.completed ? { "id": -1, "type": -1, params: ['app.media.ok' +
                                        ''], "bundleName": "com.example.myapplication", "moduleName": "entry" } : { "id": -1, "type": -1, params: ['app.media.no' +
                                        ''], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                            Image.debugLine("entry/src/main/ets/View/TodoItem.ets(74:15)", "entry");
                            Image.width(24);
                            Image.height(24);
                            Image.onClick(() => {
                                this.toggleTodo(index);
                            });
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.title);
                            Text.debugLine("entry/src/main/ets/View/TodoItem.ets(83:15)", "entry");
                            Text.fontSize(18);
                            Text.decoration({
                                type: item.completed ? TextDecorationType.LineThrough : TextDecorationType.None
                            });
                            Text.fontColor(item.completed ? '#999' : '#000');
                            Text.layoutWeight(1);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Button.createWithLabel('删除');
                            Button.debugLine("entry/src/main/ets/View/TodoItem.ets(91:15)", "entry");
                            Button.backgroundColor(Color.Red);
                            Button.fontColor(Color.White);
                            Button.fontSize(12);
                            Button.onClick(() => {
                                this.deleteTodo(index);
                            });
                        }, Button);
                        Button.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.todoList, forEachItemGenFunction, (item: TodoItem) => item.id.toString(), true, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(`总计: ${this.todoList.length} | 已完成: ${this.todoList.filter(item => item.completed).length}`);
            Text.debugLine("entry/src/main/ets/View/TodoItem.ets(111:7)", "entry");
            Text.fontSize(14);
            Text.fontColor(Color.Black);
            Text.margin({ top: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('点个赞');
            Button.debugLine("entry/src/main/ets/View/TodoItem.ets(116:7)", "entry");
            Button.backgroundColor(Color.Orange);
            Button.fontColor(Color.White);
            Button.margin({ top: 20 });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Index";
    }
}
registerNamedRoute(() => new Index(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "View/TodoItem", pageFullPath: "entry/src/main/ets/View/TodoItem", integratedHsp: "false", moduleType: "followWithHap" });
