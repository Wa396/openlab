if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ToDoListPage_Params {
    totalTasks?: Array<Resource>;
}
import ToDoItem from "@normalized:N&&&entry/src/main/ets/View/TodoItem&";
class ToDoListPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.totalTasks = [];
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ToDoListPage_Params) {
        if (params.totalTasks !== undefined) {
            this.totalTasks = params.totalTasks;
        }
    }
    updateStateVars(params: ToDoListPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private totalTasks: Array<Resource>;
    aboutToAppear() {
        this.totalTasks = DataModel.getData();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create({ space: CommonConstants.COLUMN_SPACE });
            Column.debugLine("entry/src/main/ets/View/3.ets(14:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create($r('app.string.page_title'));
            Text.debugLine("entry/src/main/ets/View/3.ets(15:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
            };
            this.forEachUpdateFunction(elmtId, this.totalTasks, forEachItemGenFunction, (item: string) => JSON.stringify(item), false, false);
        }, ForEach);
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ToDoListPage";
    }
}
registerNamedRoute(() => new ToDoListPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "View/3", pageFullPath: "entry/src/main/ets/View/3", integratedHsp: "false", moduleType: "followWithHap" });
