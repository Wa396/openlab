if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ToDoItem_Params {
    content?: string;
    isComplete?: boolean;
}
// 导出一个名为ToDoItem的结构体（组件类）
export default class ToDoItem extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.content = undefined;
        this.__isComplete = new ObservedPropertySimplePU(false, this, "isComplete");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ToDoItem_Params) {
        if (params.content !== undefined) {
            this.content = params.content;
        }
        if (params.isComplete !== undefined) {
            this.isComplete = params.isComplete;
        }
    }
    updateStateVars(params: ToDoItem_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__isComplete.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__isComplete.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    // 定义一个可选的公共属性content，用于存储待办事项的内容
    public content?: string;
    // 定义一个状态属性isComplete，用于表示待办事项是否完成，初始值为false
    private __isComplete: ObservedPropertySimplePU<boolean>;
    get isComplete() {
        return this.__isComplete.get();
    }
    set isComplete(newValue: boolean) {
        this.__isComplete.set(newValue);
    }
    // 定义一个构建器方法labelIcon，用于创建一个带有图标的标签
    labelIcon(icon: Resource, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 创建一个Image组件，显示指定的图标资源
            Image.create(icon);
            Image.debugLine("entry/src/main/ets/View/2.ets(16:5)", "entry");
            // 创建一个Image组件，显示指定的图标资源
            Image.objectFit(ImageFit.Contain);
            // 创建一个Image组件，显示指定的图标资源
            Image.width(28);
            // 创建一个Image组件，显示指定的图标资源
            Image.height(28);
            // 创建一个Image组件，显示指定的图标资源
            Image.margin(20);
        }, Image);
    }
    // 组件的构建方法，用于生成组件的UI
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 创建一个水平布局Row
            Row.create();
            Row.debugLine("entry/src/main/ets/View/2.ets(26:5)", "entry");
            // 创建一个水平布局Row
            Row.borderRadius(24);
            // 创建一个水平布局Row
            Row.backgroundColor({ "id": 16777226, "type": 10001, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            // 创建一个水平布局Row
            Row.width('93.3%');
            // 创建一个水平布局Row
            Row.height(64);
            // 创建一个水平布局Row
            Row.onClick(() => {
                // 点击组件时，切换isComplete状态
                this.isComplete = !this.isComplete;
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            // 根据isComplete状态决定显示哪个图标
            if (this.isComplete) {
                this.ifElseBranchUpdateFunction(0, () => {
                    // 如果待办事项已完成，显示“ok”图标
                    this.labelIcon.bind(this)({ "id": 16777229, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    // 如果待办事项未完成，显示“no”图标
                    this.labelIcon.bind(this)({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            // 创建一个Text组件，显示待办事项的内容
            Text.create(this.content);
            Text.debugLine("entry/src/main/ets/View/2.ets(37:7)", "entry");
            // 创建一个Text组件，显示待办事项的内容
            Text.fontSize(20);
            // 创建一个Text组件，显示待办事项的内容
            Text.opacity(this.isComplete ? 0.5 : 1);
            // 创建一个Text组件，显示待办事项的内容
            Text.decoration({ type: this.isComplete ? TextDecorationType.LineThrough : TextDecorationType.None });
        }, Text);
        // 创建一个Text组件，显示待办事项的内容
        Text.pop();
        // 创建一个水平布局Row
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ToDoItem";
    }
}
registerNamedRoute(() => new ToDoItem(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "View/2", pageFullPath: "entry/src/main/ets/View/2", integratedHsp: "false", moduleType: "followWithHap" });
